/*====*====*====*====*====*====*====*====*====*====*====*====*====*====*====*====*====*====*

                                I E C     S L A V E

                              S O U R C E     F I L E

*====*====*====*====*====*====*====*====*====*====*====*====*====*====*====*====*====*====*/
/*!
 * @file iec62056_21_slave.c
 *
 * @brief This file is the implementation of the protocol IEC 62056-21.
 *
 * @details IEC 62056-21 is used to organize and manage communication between meter
 * and both HHU(Optical) and user interface(RS485).
 *
 * <b>References</b>\n
 * -  Manual of IEC 62056-21.
 * -  Design document of the protocol.
 * -  Reference document of the standard.
 *
 * <b>Edit History For File</b>\n
 *  This section contains comments describing changes made to this file.\n
 *  Notice that changes are listed in reverse chronological order.\n
 * <table border>
 * <tr>
 *   <td><b> when </b></td>
 *   <td><b> who </b></td>
 *   <td><b> what, where, why </b></td>
 * </tr>
 * <tr>
 *   <td> 14/04/13 </td>
 *   <td> islam.elshahat </td>
 *   <td> Cancel shared buffer. </td>
 * </tr>
 * <tr>
 *   <td> 03/03/13 </td>
 *   <td> islam.elshahat </td>
 *   <td> Save configure record after commands handling. </td>
 * </tr>
 * <tr>
 *   <td> 28/02/13 </td>
 *   <td> islam.elshahat </td>
 *   <td> Make a shared buffer between RF LINK and IEC. </td>
 * </tr>
 * <tr>
 *   <td> 25/02/13 </td>
 *   <td> islam.elshahat </td>
 *   <td> Update waiting to change baud rate period.</td>
 * </tr>
 * <tr>
 *   <td> 20/02/13 </td>
 *   <td> islam.elshahat </td>
 *   <td> Reply by reject if the packet not valid.</td>
 * </tr>
 * <tr>
 *   <td> 10/02/13 </td>
 *   <td> islam.elshahat </td>
 *   <td> Check authentication date with the same function of RFID cards. Use the basic function to calculate the crc. Save configure meter record after the authentication.</td>
 * </tr>
 * <tr>
 *   <td> 15/01/13 </td>
 *   <td> islam.elshahat </td>
 *   <td> Solve bug of maximum number of event records to read per time.</td>
 * </tr>
 * <tr>
 *   <td> 09/01/13 </td>
 *   <td> islam.elshahat </td>
 *   <td> Solve optical stop in mode 2,3 bug.</td>
 * </tr>
 * <tr>
 *   <td> 30/12/12 </td>
 *   <td> islam.elshahat </td>
 *   <td> Wait 0.5 second after changing baud rate and move scratch card status to instantaneous data and remove scratch card mode.</td>
 * </tr>
 * <tr>
 *   <td> 09/12/12 </td>
 *   <td> islam.elshahat </td>
 *   <td> Modify saving in configure meter log to be after handling commands.</td>
 * </tr>
 * <tr>
 *   <td> 29/11/12 </td>
 *   <td> islam.elshahat </td>
 *   <td> Add scratch card mode and add ability to read tariff and payment and tax configuration.</td>
 * </tr>
 * <tr>
 *   <td> 21/11/12 </td>
 *   <td> islam.elshahat </td>
 *   <td> Remove display update and solve collect data mode bug.</td>
 * </tr>
 * <tr>
 *   <td> 04/11/12 </td>
 *   <td> islam.elshahat </td>
 *   <td> Integrate with control and modify the system to support listening from
 *        one source either optical or RS.
 *        Also mode 3 is modified to reply by authentication packet instead
 *        of acknowledgment packet.</td>
 * </tr>
 * <tr>
 *   <td> 15/10/12 </td>
 *   <td> islam.elshahat </td>
 *   <td> Reply with main meter data in mode 2, Solve bug in Rx char ISR when the packet type is data.
 *        Use S_UART3 instead of S_UART2. </td>
 * </tr>
 * <tr>
 *   <td> 25/09/12 </td>
 *   <td> aibraheem </td>
 *   <td> Integrate with metering. </td>
 * </tr>
 * <tr>
 *   <td> 24/09/12 </td>
 *   <td> aibraheem </td>
 *   <td> Integrate with metering (not complete). </td>
 * </tr>
 * <tr>
 *   <td> 26/08/12 </td>
 *   <td> wkadry </td>
 *   <td> Modify comments and solve CRC calculation bug. </td>
 * </tr>
 * <tr>
 *   <td> 31/07/12 </td>
 *   <td> islam.elshahat </td>
 *   <td> Optimize and add comments. </td>
 * </tr>
 * <tr>
 *   <td> 30/07/12 </td>
 *   <td> islam.elshahat </td>
 *   <td> Created </td>
 * </tr>
 * </table>\n
 */

/*==========================================================================================

                                 INCLUDE FILES FOR MODULE

==========================================================================================*/
#include "iec62056_21_slave.h"
#include "string.h"
#include "comm.h"
//#include "dependencies_layer.h"
#include "dependencies_layer.h"
#include "ctrl.h"
/* #include "dependencies_layer.h" -- see dependencies_layer.h */
/* #include "dependencies_layer.h" -- see dependencies_layer.h */
#include "UART_Interface.h"
#include "GPIO_Interface.h"
/* #include "dependencies_layer.h" -- see dependencies_layer.h */
//#include "Flash_app.h"
#include "comm.h"
/* #include "dependencies_layer.h" -- see dependencies_layer.h */
/* #include "MODEM.h" */ /* module removed from the DRU build */
/* #include "Dlms_PhyLp.h" */ /* module removed from the DRU build */
/* #include "iec62056_21_master.h" */ /* module removed from the DRU build */
/*==========================================================================================

                          DEFINITIONS AND DECLARATIONS FOR MODULE

This section contains definitions for constants, macros, types, variables and other
items needed by this module.

==========================================================================================*/


/*------------------------------------------------------------------------------------------
                                         Data Types
------------------------------------------------------------------------------------------*/
#ifdef IEC_62056_21_SLAVE
/*!
 * @par Description:
 *   This enumerator contains receiving character states.
 */
#endif

/*------------------------------------------------------------------------------------------
                                    External Variables
------------------------------------------------------------------------------------------*/

/*!< LCD icons connection flag (optical, RS485). If bit value is 0 means
 * disconnected and if bit value is 1 means connected. Bit 0 for optical icon
 * and Bit 1 for RS 485 icon.*/
uint8_t iec62056_21_lcd_icon_flg;
extern uint8_t DotMatrixOpticalFlag;
extern uint8_t FinishedDotMatrixFlag;
uint8_t IEC_DRU_flag = 0;
uint8_t DotmatrixSend = 0;
/*------------------------------------------------------------------------------------------
                                     Local Variables
------------------------------------------------------------------------------------------*/
#ifdef IEC_62056_21_SLAVE
#ifdef IEC_62056_21_ISR_ENABLE
#ifdef optical_DMA_Enable
uint32_t last_iec_62056_21_DMA_index = 0;
#endif
uint16_t iec_62056_21_isr_index=0,uu2=0,temp_size2=0;
#ifndef PLC_MODEM_IEC_TEST
uint8_t iec_62056_21_isr_buffer[1024];
#else
uint8_t iec_62056_21_isr_buffer[650];
#endif
#endif
#ifdef RS485_NetworkDiscovery_Feature
uint8_t SCAN_MODE_Flag = 0;
#endif
uint8_t iec_comm_buffer[IEC_BUFFER_SIZE]; /*!< Buffer of IEC protocol communication to receive packets in.*/
uint16_t pckt_size; /*!< Size of packet in the buffer.*/
static uint16_t buffer_index; /*!< index of communication buffer.*/
static uint8_t rx_char; /*!< Received character.*/
static uint8_t rx_char_state = WAIT_PCKT_STRT; /*!< Receiving character state.*/
static uint8_t char_mask = STANDARD_MASK; /*!< Character mask to be applied on the rx. char.*/
uint8_t pckt_type; /*!< Packet type #pckt_type_t.*/
uint8_t state = IDLE; /*!< Current protocol state #protocol_states_t.*/
uint8_t second_counter =0; /*!< Second counter used to detect communication timeout.*/
uint16_t rs485_counter; /*!< Counter used to detect RS485 timeout in sec.*/
static uint8_t wait_baud_rate_flag; /*!< Wait master to change the baud rate flag.*/
static uint8_t wait_baud_rate_readout_flag;
uint32_t iec62056_21_wait_baud_rate_counter; /*!< Counter of waiting master to change the baud rate.*/
static uint16_t last_operator_id; /*!< ID of the last operator configured the meter by IEC.*/
/*! Structure containing strings used for data readout standard mode.*/
const readout_mode_object_t readout_mode_object[MAX_NUM_ENRG_TYPE] =
{
  {
    "1.8.0(",
    "*kWh)\r\n",
    7
  },
  {
    "3.8.0(",
    "*kVARh)\r\n",
    9
  },
  {
    "9.8.0(",
    "*kVAh)\r\n",
    8
  }
};
/*! Data packet end string ! CR LF ETX.*/
const uint8_t data_pckt_end[4] = {'!', CR, LF, ETX};
uint8_t optical_sec_counter;
#endif
uint8_t tmp_crc2 = 0 ;
uint16_t bytes_num = 0;
uint8_t g_jig_start=0;
#define  JIG_BUFFER_SIZE        10 
uint8_t JIG_ReadBuffer[JIG_BUFFER_SIZE];
uint8_t req_count_byte=0;
uint8_t passing_wrong_pckt_flag=0;
/*------------------------------------------------------------------------------------------
                                          Macros
------------------------------------------------------------------------------------------*/
#if (defined HDLC_PROTOCOL || defined IEC_62056_21_SLAVE || defined DLMS_ENABLED)
#ifdef PLC_MODEM_IEC_TEST
/* #include "PLC_App.h" */ /* module removed from the DRU build */
#define S_UART_SEND_FRAME(a,b,c) PLC_Send(b,c)
#endif


/*==========================================================================================

                                   FUNCTION DECLARATIONS

==========================================================================================*/

/*!
 * @brief This function is used to send any frame to optical or RS485.
 *
 * @par Description:
 * Control both channels of optical and RS485 to transmit data and listen
 * to future received packet.
 *
 * @return
 * - None.
 *
 * @note: In case of optical, the communication is full duplex so when we receive
 * request without meter ID, hardware is configured to receive from optical only.
 * In case of RS485, the communication is half duplex so before transmission,
 * code should configure channel for transmission. After transmission ends, the
 * channel should configured again to receive packets from RS485.
 */
void send_frame(uint8_t *data_ptr, uint16_t length)
{
  /*!@par Pseudo Code:*/
  /*! - If the session is RS485 session, configure the channel for transmission.*/
//#ifdef ASHNTTI_PROJECT  
//#ifdef RS485_ENABLE
  bytes_num = 0;
  
#ifdef GROUP_METERING
  uint8 tmp_buf[2]={0xAA,0xAA};

#endif
  uint8_t state = (!(iec62056_21_lcd_icon_flg & 0x01));

  /*! - If the session is RS485 session, configure the channel for transmission.*/
  if(state)
    IEC_62056_21_LISTEN_OPT_SEND_RS();
  else
//#endif
    IEC_62056_21_LISTEN_RS_SEND_OPT();
  /*! - Send frame.*/
  Delay_ms(10); 
  
  if(0/*state*/)
  {
#ifdef GROUP_METERING
#ifdef HDLC_PROTOCOL
    S_UART_SEND_FRAME(CONNECTED_METER_MODEM,tmp_buf,2);
#else
    S_UART_SEND_FRAME(RS_UART_PORT_NUMBER,tmp_buf,2);
#endif
#endif
#ifdef HDLC_PROTOCOL
    S_UART_SEND_FRAME(CONNECTED_METER_MODEM,data_ptr,length);
#else
  	S_UART_SEND_FRAME(RS_UART_PORT_NUMBER,data_ptr,length);
#endif
  }
  else
  {
    //S_UART_DISABLE_RX(OPTICAL_UART_PORT_NUMBER);
    S_UART_SEND_FRAME(OPTICAL_UART_PORT_NUMBER,data_ptr,length);
    //S_UART_ENABLE_RX(OPTICAL_UART_PORT_NUMBER);
  }
  /*! - If the session is RS485 session, configure the channel again for receiving.*/
//#ifdef RS485_ENABLE
  if(state)
//#endif
//#ifdef RS485_ENABLE
    IEC_62056_21_LISTEN_RS_SEND_OPT();
  else
//#endif
    IEC_62056_21_LISTEN_OPT_SEND_RS();
//#else
 // IEC_62056_21_SEND_FRAME(data_ptr, length);
//#endif
#ifdef IEC_62056_21_SLAVE
  rs485_counter=0;
#endif
}
#endif
#ifdef IEC_62056_21_SLAVE

#ifdef RS485_NetworkDiscovery_Feature
static void initialize_uart_scan_mode() {
    S_UART_INIT((UART_TypeDef*)RS_UART_PORT_NUMBER, '0', UART_WORDLEN_8B, Dlms_NoParity);
}

static void handle_frame_send(uint8_t *data, uint8_t length) {
    iec62056_21_lcd_icon_flg |= IEC_RS;
    initialize_uart_scan_mode();
    send_frame(data, length);
}

static void uint32_t_BitsToBytes(uint32_t Bytes, uint8_t* bits){
  for(uint8_t i = 0 ; i < 32; i++){
    bits[i] = (Bytes & (1 << i)) ? 0xFF : 0;
  }
}

uint8_t isMeterConnected(uint8_t* buff){
  uint32_t meters_serial;
  for(uint8_t i = 0; i < buff[1]; i++){
    meters_serial = 0;
    meters_serial |= (buff[2 + (i*5)]     & 0x7F) << 28;
    meters_serial |= (buff[2 + (i*5) + 1] & 0x7F) << 21;
    meters_serial |= (buff[2 + (i*5) + 2] & 0x7F) << 14;
    meters_serial |= (buff[2 + (i*5) + 3] & 0x7F) << 7;
    meters_serial |=  buff[2 + (i*5) + 4] & 0x7F;
    if(!memcmp((uint8_t*)&meters_serial, (uint8_t*)&ctrl_cfg.id.Customer, 4))
      return 1;
  }
  return 0;
}

void handle_scan_mode_isr(uint8_t rx_byte){
    static uint8_t scan_buffer[MAX_FRAME_LENGTH];
    static uint32_t Check_arbitration = 0;
    static uint8_t scan_buffer_cnt = 0;
    static uint8_t start_scan = 0;
    static uint8_t byte_num = 0;
    uint8_t current_byte_position = rx_byte & 0x3F;
    uint8_t is_same_bit_arbitration = (rx_byte >> 7) == (scan_buffer[current_byte_position - 1]) >> 7;
    uint8_t is_Check_arbitration_matched = (Check_arbitration == (0xFFFFFFFF >> (32 - current_byte_position)) >> 1);

  initialize_uart_scan_mode();
  if (rx_byte == FRAME_START_BYTE) {
    uint32_t serial_number = ctrl_cfg.id.Customer;
    uint32_t_BitsToBytes(serial_number, scan_buffer);
    scan_buffer[MAX_FRAME_LENGTH - 1] = calc_crc((uint8_t*)&serial_number, sizeof(serial_number), CRC);
    scan_buffer_cnt = 0;
    Check_arbitration = 0;
    start_scan = 1;
    //Exit_Counter = 70;
    iec62056_21_lcd_icon_flg |= IEC_RS;
    handle_frame_send(scan_buffer, 1);
    byte_num = 1;
  }
  else if (start_scan && (scan_buffer_cnt <= 10 && (rx_byte != FRAME_END_BYTE)) && (current_byte_position == byte_num) && is_same_bit_arbitration && is_Check_arbitration_matched) {    
    
      scan_buffer_cnt = 0;
      byte_num++;
      Check_arbitration |= 1 << (current_byte_position - 1);
      iec62056_21_lcd_icon_flg |= IEC_RS;
      //Exit_Counter = 70;
      handle_frame_send(&scan_buffer[current_byte_position], 1);
    
  } 
  else if((start_scan && (byte_num == 33)) || (scan_buffer_cnt > 200) || (rx_byte == FRAME_END_BYTE)){
    if (Check_arbitration == 0xFFFFFFFF && rx_byte == FRAME_END_BYTE)
      ctrl_cmd(CTRL_BEEP_TONE0);
    
    SCAN_MODE_Flag = 0;
    start_scan = 0;
    Check_arbitration = 0;
    scan_buffer_cnt = 0;
  }
  scan_buffer_cnt++;
}

#endif
/*!
 * @brief Reset the communication buffer of IEC 62056-21 protocol.
 *
 * @par Description:
 * Reset the communication buffer (index and state) of IEC 62056-21 protocol.
 *
 * @return
 * - None.
 */
void reset_buffer(void)
{
  /*!@par Pseudo Code:*/
  /*! - Reset buffer index.*/
  buffer_index = 0;
  /*! - Receiving character state = wait packet start.*/
  rx_char_state = WAIT_PCKT_STRT;
}

/*!
 * @brief Reset the state machine of IEC 62056-21 protocol.
 *
 * @par Description:
 * Reset all variables of protocol to return to initial state.
 *
 * @return
 * - None.
 */
void reset_state_machine(void)
{
#if (!defined DLMS_ENABLED && !defined GROUP_METERING)
	//if(IEC_DRU_flag || Boot_loader_flag)
#endif
	{

		/*!@par Pseudo Code:*/
		reset_buffer();
		/*! - Check if the operator ID changed, save a record in configure meter log.*/
#ifdef CTRL_CFG_METER_LOG
		if(last_operator_id)
		{
			if ( iec62056_21_lcd_icon_flg & IEC_OPTICAL)
				IEC_62056_21_SAVE_CFG_METER_REC(last_operator_id,CTRL_OPTICAL);
			else
				IEC_62056_21_SAVE_CFG_METER_REC(last_operator_id,CTRL_RFID);
		}
#endif
		last_operator_id = 0;
		/*! - Initialize UART settings*/
		char_mask = STANDARD_MASK;
#if defined(DLMS_ENABLED) || defined (HDLC_PROTOCOL)
                if(!rise_iec_flag)
#endif
        {IEC_62056_21_UART_INIT(Dlms_EvenParity, /*300*/'0');}
		/*! - Reset state of protocol to be idle.*/
		state = IDLE;
		/*! - Reset flag of rx packets.*/
		pckt_size = 0;
		/*! - Clear seconds counter.*/
		second_counter = 0;
        rs485_counter = 0;
		/*! - Reset the flag of waiting master to change the baud rate.*/
		wait_baud_rate_flag = FALSE;
		wait_baud_rate_readout_flag = FALSE;
		/*! - Clear optical flag and update LCD.*/
		iec62056_21_lcd_icon_flg &= ~IEC_OPTICAL;
		/*! - Listen to both optical and RS485.*/
		IEC_62056_21_LISTEN_BOTH();
		IEC_DRU_flag = 0;
        bytes_num = 0;
#ifdef CONSOL_FEATURE
        memset(iec_62056_21_isr_buffer, 0,sizeof(iec_62056_21_isr_buffer));
        iec_62056_21_isr_index =0;  
#endif
	}
#if defined(DLMS_ENABLED) || defined (HDLC_PROTOCOL)
  rise_iec_flag=0;
#endif
  passing_wrong_pckt_flag=0;
}

/*!
 * @brief Save and increment index of buffer and check for buffer size limit.
 *
 * @par Description:
 * Save and increment the buffer index. If the buffer is full return to IDLE state and
 * clear the index.
 *
 * @return
* - None.
*/
void save_char_in_buffer(void)
{
  /*!@par Pseudo Code:*/
  /*! - If buffer is full */
  /*! - Reset the state machine.*/
  if(buffer_index >= IEC_BUFFER_SIZE)
    reset_state_machine();
  /*! - else, Save the character and increment index of buffer*/
  else
  {
    iec_comm_buffer[buffer_index] = rx_char;
    buffer_index++;
  }
}

/*!
 * @brief End of packet operations.
 *
 * @par Description:
 * This function does all required operations at the end of receiving a packet.
 *
 * @return
 * - None.
 */
void pckt_end(void)
{
  /*!@par Pseudo Code:*/
  /*! - Save character in buffer.*/
  save_char_in_buffer();
  /*! - if the buffer is not exceeded.*/
  if(buffer_index != 0)
  {
    /*! - Packet size equals buffer index.*/
    pckt_size = buffer_index;
    /*! - Reset communication buffer.*/
    reset_buffer();
    /*! - Reset second counter.*/
    second_counter = 0;
    //rs485_counter = 0;
  }
}

/*!
 * @brief Check that received packet obeys format.
 *
 * @par Description:
 * Check coming new packet is valid get thier type for data packet and save mode
 * if the coming packet is acknowledgement packet.
 * - For request packet, check for '?', '!', packet size, meter ID.
 * - For acknowledgment packet, check packet size, baud rate and '0'.
 * - For data packet, check for BCC and block size.
 *
 * @return
* - 8 bits Type of packet #pckt_type_t.
 */
uint8_t check_pckt_valid(void)
{
#ifdef RS485_NetworkDiscovery_Feature 
  uint8_t crc_byte;
#endif
  uint16_t data_size;
  /*!@par Pseudo Code:*/
  switch(pckt_type)
  {
#ifdef RS485_NetworkDiscovery_Feature
  case SCAN_PCKT:
    pckt_type = INVALID_PCKT;
    crc_byte = calc_crc(iec_comm_buffer, (pckt_size - 4),CRC);
    if(pckt_size == ((iec_comm_buffer[1] * 5) + 6) && (((iec_comm_buffer[(iec_comm_buffer[1] * 5) + 2]) == (crc_byte&0x7F) ))){
      pckt_type = SCAN_PCKT;
      state = SCAN;
    }
    break;
#endif
  case RQST_PCKT:
    /*! - If the received packet is: request packet.*/
    /*! - Check for '?', '!', meter ID, Packet size.*/
    if((iec_comm_buffer[1] == '?') && (iec_comm_buffer[pckt_size - 3] == '!')\
        && (pckt_size == 5) || ((pckt_size >  5)\
                                && (ascii_to_int(iec_comm_buffer + 2, pckt_size - 5) == IEC_62056_21_GET_CUSTOMER_ID())))
    {
      if(pwr_up_sec_cntr > 7)
      {
        IEC_DRU_flag = 1;
       
      }
       break;
    }
   pckt_type = INVALID_PCKT;
    break;
  case ACK_PCKT:
    /*! - If the received packet is: acknowledgment packet.*/
    /*! - Check for '0', '!', baud rate, mode.*/
    if((pckt_size == 6))
      break;
    pckt_type = INVALID_PCKT;
    break;
  case DATA_PCKT:
    /*! - If the received packet is: data packet.*/
    /*! - Check for data size, BCC.*/
    data_size = iec_comm_buffer[1] + ((uint16_t)iec_comm_buffer[2] << 8);
    if ((state == WAIT_BOOTLOADER_DATA))
    {
      tmp_crc2 = (calc_crc(iec_comm_buffer + 1, pckt_size - 2,CRC));
    }
    else
    {
#ifdef GROUP_METER_FEATURE
      tmp_crc2 = (calc_crc(iec_comm_buffer + 1, pckt_size - 2,CRC))& 0x7F;
#else
      tmp_crc2 = (calc_crc(iec_comm_buffer + 1, pckt_size - 2,checksum))& 0x7F;
#endif
    }
    if((data_size == (pckt_size - 6)) \
        && (iec_comm_buffer[pckt_size - 1] == tmp_crc2))
    {
      /*! - Get type of the data packet.*/
      if((iec_comm_buffer[3] == DATA_END_COMM_TYPE) && ((state == WAIT_CMD)||(state == WAIT_BOOTLOADER_DATA) || (state == WAIT_DATA_RQST)))
      {
        pckt_type = DATA_END_COMM_PCKT; 
        /* Check if the command was PLC then call the reset function */
        //if(iec_comm_buffer[6] == PLC_FIRMWARE_SAVING_CMD)
        //{
         //  plc_reset_var();
        //}
        //else
        //{
          /* Do nothing */
        //}
       
      }

      else if(iec_comm_buffer[3] == DATA_CMD_TYPE)
        pckt_type = DATA_CMD_PCKT;
      else if(iec_comm_buffer[3] == DATA_AUTHNC_TYPE)
      {
        pckt_type = DATA_AUTHNC_PCKT;//reda
        if(!(convertToInt16(&iec_comm_buffer[8], BS_BIG_ENDIAN_TYPE) == 0))
        {
          if((convertToLong32(&iec_comm_buffer[4], BS_BIG_ENDIAN_TYPE) != IEC_62056_21_GET_CUSTOMER_ID())\
            || (convertToInt16(&iec_comm_buffer[8], BS_BIG_ENDIAN_TYPE) != IEC_62056_21_GET_DEPART_ID())\
            || (!check_card_date(iec_comm_buffer[12], iec_comm_buffer[13], \
              iec_comm_buffer[14])))
            pckt_type = INVALID_PCKT;
        }
        customer_flag = 0;
      }
      else if(iec_comm_buffer[3] == DATA_BOOTLOADER_TYPE)
      {
       pckt_type = DATA_BOOTLOADER_PCKT;
      }
      else if(((iec_comm_buffer[3] >= MIN_RAW_DATA) && (iec_comm_buffer[3] <= MAX_RAW_DATA)) || ((iec_comm_buffer[3] >= MIN_REC_DATA) && (iec_comm_buffer[3] <= MAX_REC_DATA)))
        pckt_type = DATA_RQST_PCKT;
      else
      {
        pckt_type = INVALID_PCKT;
        if(iec_comm_buffer[3] != DATA_END_COMM_TYPE) //TODO this condition will removed after SW modification in set serial meter.
          passing_wrong_pckt_flag=1;
      }
      break;
    }
    pckt_type = INVALID_PCKT;
    break;
  }
  return pckt_type;
}

/*!
 * @brief Buffer the received characters to form packets.
 *
 * @par Description:
 * Detect different packets start and end and set a flag when a packet
 * is received descriped by the following state machine: \image html Rx_Char.jpg
 *
 * @return
 * - None.
 */
void iec_62056_21_rx_char_isr(uint8_t rx_byte)
{ 
#if defined(DLMS_ENABLED) || defined (HDLC_PROTOCOL)
  if(!rise_iec_flag)
    return;
#endif
  /* Self-test/tooling mode is not built for the DRU, so this branch (which only
     ran while a self-test was active) can never be taken. */
#ifdef IEC_62056_21_ISR_ENABLE
    /*!@par Pseudo Code:*/
  /*! - Clear UART interrupt FLAG.*/
  /*! - Read received character.*/
  iec_62056_21_isr_buffer[iec_62056_21_isr_index] = rx_byte; 
  iec_62056_21_isr_index++;
  
  if(iec_62056_21_isr_index >= sizeof(iec_62056_21_isr_buffer))
  {
    iec_62056_21_isr_index = 0;
  }
  IEC_62056_21_CLR_INT_FLG();
  
}

void iec_62056_21_process_isr(uint8_t rx_byte)
{
#endif
  static uint8_t ack_3bytes_counter=0;

  /*!@par Pseudo Code:*/
  /*! - Clear UART interrupt FLAG.*/
  bytes_num++;
  if(bytes_num > IEC_BUFFER_SIZE)
  {
    bytes_num = 0;
    reset_state_machine();
  }
  IEC_62056_21_CLR_INT_FLG();
  /*! - Read received character.*/
  rx_char = rx_byte;
#ifndef PLC_MODEM
  /* was: SelfTest_gGetSelfTest()==1 || ...  -- self-test not built for the DRU */
  if(pwr_up_sec_cntr < PWR_UP_NO_REC_TIME)
  {
    if(pwr_up_sec_cntr < PWR_UP_NO_REC_TIME)
    {
      rx_char =  rx_byte & 0x7f;
    }
      save_char_in_buffer();
      if(pwr_up_sec_cntr < PWR_UP_NO_REC_TIME)
      {
        rx_char =  rx_byte & 0x7f;
        if( buffer_index == 3 && !memcmp("JIG",iec_comm_buffer ,sizeof("JIG")))
        {
          g_jig_start = 1;
          reset_buffer();
          memset(iec_comm_buffer,0,sizeof(iec_comm_buffer));
        }
        else if( buffer_index == 3 && !memcmp("INF",iec_comm_buffer ,sizeof("INF")))
        {
          IEC_62056_21_UART_INIT(Dlms_EvenParity, /*300*/'0'); ////
          Delay_ms(10);
          iec62056_21_lcd_icon_flg |= IEC_OPTICAL;
          reset_buffer();
          memset(iec_comm_buffer,0,sizeof(iec_comm_buffer));
          /* EEPROM_read(Data_eeprom_address ,JIG_ReadBuffer,EEPROM_TEST_PAGE, EEPROM_PAGE_SIZE); */  /* EEPROM not built for the DRU */
          send_frame("ERROR=",5);
          send_frame(JIG_ReadBuffer,10);
          reset_buffer();
          memset(iec_comm_buffer,0,sizeof(iec_comm_buffer));
        }
      }
        
  }
#endif
  if (state != WAIT_BOOTLOADER_DATA)
  {
    rx_char /*= IEC_62056_21_GET_RX_CHAR()*/ &= char_mask;
  }
  /*! - If there is no packet in the buffer.*/
  if(!pckt_size)
  {
    switch(rx_char_state)
    {
    case WAIT_PCKT_STRT:
      /*! - If the current state is: Waiting a packet start*/
      /*! - If the received character is / or ACK.*/
#ifndef GROUP_METERING
#ifdef RS485_NetworkDiscovery_Feature
      if(((rx_char == '$') && (state == IDLE)))
      {
        pckt_type = SCAN_PCKT;
        rx_char_state = DATA_COLLECT;
        save_char_in_buffer();
      }
#endif
      if(((rx_char == '/') && (state == IDLE)) || ((rx_char == ACK) && (state == WAIT_ACK)))
#else //working as a master & slave meter
      if((IEC_62056_21_MASTER_SLAVE_MODE == iec62056_21_MASTER_MODE && ((rx_char == '/') && (state == WAIT_ACK)) || ((rx_char == ACK) && ((state == WAIT_AUTHNC) || (state == WAIT_CMD) || (state == SEND_BOOTLOADER_DATA))))||
         (IEC_62056_21_MASTER_SLAVE_MODE == iec62056_21_SLAVE_MODE && ((rx_char == '/') && (state == IDLE)) || ((rx_char == ACK) && (state == WAIT_ACK))))
#endif
      {
        /*! Get packet type request or acknowledgement.*/
        pckt_type = RQST_PCKT;
        rx_char_state = WAIT_CR;
#ifdef GROUP_METERING
        if(IEC_62056_21_MASTER_SLAVE_MODE == iec62056_21_SLAVE_MODE)
        {
          rx_char_state = WAIT_3F_BYTE_IN_REQ;
        }
        req_count_byte=0;
        if(rx_char == ACK && state ==SEND_BOOTLOADER_DATA)
        {
          pckt_type = ACK_PCKT;
          rx_char_state = WAIT_3_BYTES_ACK;
          ack_3bytes_counter=0;
        }
        else if (rx_char == ACK )
#else
        if (rx_char == ACK)
#endif
        {
          pckt_type = ACK_PCKT;
          /*! - Move to WAIT CR state.*/
          rx_char_state = WAIT_CR;
        }
        /*! - Save the character in the buffer*/
        save_char_in_buffer();
      }
      /*! - If the received character is STX.*/
      else if((rx_char == STX) && ((state == WAIT_DATA_RQST)\
                                   || (state == WAIT_CMD)\
                                   || (state == WAIT_AUTHNC)\
                                   || (state == WAIT_BOOTLOADER_DATA)\
                                   || (state == COLLECT_READOUT_DATA)))
      {
        /*! Packet type is data packet.*/
        pckt_type = DATA_PCKT;
        /*! - Move to WAIT ! state.*/
        rx_char_state = DATA_COLLECT;
        /*! - Save the character in the buffer*/
        save_char_in_buffer();
        
      }
    ///  else
     //   reset_state_machine();//in 1ph was commented
      break;
    case WAIT_CR:
      /*! - If the current state is: Waiting CR*/
      /*! - If the received character is CR, Move to wait LF state.*/
      if(rx_char == CR)
      {
        rx_char_state = WAIT_LF;
      }
      if((rx_char != CR) && (pckt_type == DATA_PCKT))
      {
        reset_state_machine();
        break;
      }
      /*! - Save character in buffer.*/
#ifdef GROUP_METERING
      if(rx_char == CR ||((pckt_type==RQST_PCKT) && (rx_char >= 0x30 && rx_char <= 0x39) || rx_char == 'S' || rx_char == 'E' || rx_char == '!')||\
        ((pckt_type==ACK_PCKT)))
      {
        save_char_in_buffer();
      }
      else
        reset_buffer();
#else
      save_char_in_buffer();
#endif
      break;
    case WAIT_LF:
      /*! - If the current state is: Waiting LF*/
      /*! - If the received character is LF.*/
      if(rx_char == LF)
      {
#ifndef GROUP_METERING
        if (pckt_type == RQST_PCKT)
#else
		if (pckt_type == RQST_PCKT && (IEC_62056_21_MASTER_SLAVE_MODE == iec62056_21_SLAVE_MODE))
#endif
        {
           if(((buffer_index+1 >  5) && (ascii_to_int(iec_comm_buffer + 2, buffer_index+1 - 5) != IEC_62056_21_GET_CUSTOMER_ID())))
           {
             reset_buffer();
             return;
           }
           
        }

        /*!- If this is not a data packet, packet end.*/
        if(pckt_type != DATA_PCKT)
        {
          pckt_end();
          break;
        }
        /*!- If this is a data packet, move to wait ETX.*/
        rx_char_state = WAIT_ETX;
        /*! - Save in buffer.*/
        save_char_in_buffer();
      }
      /*! - If the received character is not LF, reset state machine.*/
     // else
       // reset_state_machine();//in 1ph it was commented in all the code
      break;
    case DATA_COLLECT:
      save_char_in_buffer();
#ifdef RS485_NetworkDiscovery_Feature
      if(iec_comm_buffer[0] == '$' /*&& (((iec_comm_buffer[(iec_comm_buffer[1] * 4) + 2]) == crc_byte) || (iec_comm_buffer[(iec_comm_buffer[1] * 4) + 2]) == (crc_byte&0x7F) )*/){
        if(buffer_index == ((iec_comm_buffer[1] * 5) + 3))
          rx_char_state = WAIT_CR;
      }
      else if((buffer_index > 2) && (buffer_index > (iec_comm_buffer[1] + ((uint16_t)iec_comm_buffer[2] * 256))))
#else
	if((buffer_index > 2) && (buffer_index > (iec_comm_buffer[1] + ((uint16_t)iec_comm_buffer[2] * 256))))
#endif
        rx_char_state = WAIT_EXCLAMATION_MARK;
      break;
    case WAIT_EXCLAMATION_MARK:
      /*! - If the current state is: Waiting a '!'*/
      /*! - If the received character is !, Move to wait CR state.*/
      if(rx_char == '!')
      {
        rx_char_state = WAIT_CR;
        /*! - Save character in buffer.*/
        save_char_in_buffer();
      }
      //else
       // reset_state_machine();
      break;
    case WAIT_ETX:
      /*! - If the current state is: Waiting ETX */
      /*! - If the received character is ETX.*/
      if(rx_char == ETX)
      {
        /*! - Move to state wait BCC.*/
        rx_char_state = WAIT_BCC;
        /*! - Save in buffer.*/
        save_char_in_buffer();
      }
      /*! - If the received character is not ETX, reset state machine.*/
      //else
       // reset_state_machine();
      break;
    case WAIT_BCC:
      /*! - If the current state is: Waiting BCC*/
      /*! - Packet End.*/
      pckt_end();
      break;

    case WAIT_3_BYTES_ACK:
      /*! - If the current state is: Waiting BCC*/
      ack_3bytes_counter++;
      if(rx_char == CR && ack_3bytes_counter>=4)
        rx_char_state = WAIT_LF;
      save_char_in_buffer();
	  break;
	
     case WAIT_3F_BYTE_IN_REQ:
      if(rx_char == '?')
      {
        req_count_byte=0;
        rx_char_state = WAIT_CR; //WAIT_METER_ID
        save_char_in_buffer();
      }
      else
        reset_buffer();
      break;
      
    // case WAIT_METER_ID:
    //   req_count_byte++;
    //   if(rx_char >= 0x30 && rx_char <= 0x39)
    //   {
    //     save_char_in_buffer();
    //     if(req_count_byte>=9)
    //     {
    //       req_count_byte=0;
    //       rx_char_state=WAIT_CR;
    //       break;
    //     }
    //   }
    //   else
    //     reset_buffer();
    //   if(req_count_byte>=10)
    //     reset_buffer();
    //   break;
   
    }/* end of switch(Rx_Char)*/
  }
      /*RmvCodCmntA_K*/

}

#ifdef IEC_62056_21_ISR_ENABLE
void iec_62056_21_sub_task (void)
{
#ifdef optical_DMA_Enable
  iec_62056_21_isr_index = uart_DMA_getIndex(2, 256);
#endif
  if (iec_62056_21_isr_index > sizeof(iec_62056_21_isr_buffer))
    iec_62056_21_isr_index = 0;
  for (uu2 = temp_size2 ;uu2 != iec_62056_21_isr_index ;)
  {
    iec_62056_21_process_isr(iec_62056_21_isr_buffer[uu2]);
    uu2++;
    if (uu2 >= sizeof(iec_62056_21_isr_buffer))
      uu2=0;
  }
  temp_size2 = uu2;
}
#endif
/*!
 * @brief Send data packet with certain type.
 *
 * @par Description:
 * Send different types of data packets accordining to the passed type.
 *
 * @param [in] type Accordining to the type a certain packet will be sent #data_rqst_type_t.
 *
 * @return
 * - TRUE sending is successful, FALSE sending failed because there is power down
 * or number of records required is above maximum limit.
 */
uint8_t send_data_pckt(uint8_t type)
{
  /*!@par Pseudo Code:*/
  uint8_t index;
  uint32_t energy_low;
  uint16_t energy_high;
  uint8_t *buffer_ptr = iec_comm_buffer;
  uint16_t data_size;
#ifdef FILE_SYS_LOG
  uint16_t records_num;
  uint16_t records_begin;
#endif
  /*! - Save Data Packet Start (STX) in the buffer.*/
  *buffer_ptr = STX;
  buffer_ptr++;
  /*! - Send Data Block.*/
  /*! IF readout standard mode send total active, reactive and apparent energy consumption.*/
  if(type == READOUT_DATA_STND_SEND)
  {
    for(index = ACTV_ENRG; index < MAX_NUM_ENRG_TYPE; index++)
    {
      /*! - Save OBIS code of energy in the buffer.*/
      memcpy(buffer_ptr, readout_mode_object[index].obis_code, 6);
      buffer_ptr += 6;
      /* Energy registers came from the metering module, which is not built for
         the DRU. The readout keeps its OBIS record structure and reports zero
         for every energy type. */
      energy_low = 0;
      energy_high = 0;
      /*! - Convert high energy value to 6 ASCII digits and save in buffer.*/
      int_to_ascii(buffer_ptr, (uint32_t)energy_high, 6);
      buffer_ptr += 6;
      /*! - Convert high energy value to 6 ASCII digits and save in buffer.*/
      int_to_ascii(buffer_ptr, energy_low / 1000, 6);
      buffer_ptr += 6;
      /*! - Save the unit of energy in the buffer.*/
      memcpy(buffer_ptr, readout_mode_object[index].unit, readout_mode_object[index].unit_size);
      buffer_ptr += readout_mode_object[index].unit_size;
    }
  }
  /*! If the mode is read data specific mode.*/
  else if(type == MAIN_METER_DATA)
  {
    if(IEC_62056_21_SLAVE_OPTCL_CONCT_FLG)
      /*! - Increment meter read data counter.*/
      IEC_62056_21_EVE_DATA_READ();
    /*! - Send new data block.*/
    iec_comm_buffer[3] = MAIN_METER_DATA;
    data_size = IEC_62056_21_WRITE_MAIN_DATA_LIST((uint8_t*)iec_comm_buffer + 4) + 3;
    buffer_ptr += data_size;
    iec_comm_buffer[1] = (uint8_t)data_size;
    iec_comm_buffer[2] = (uint8_t)(data_size >> 8);
  }
  /*! If the request is for raw data of the meter.*/
  else if((type >= MIN_RAW_DATA) && (type <= MAX_RAW_DATA))
  {
    /*! - Send Raw Data. Fill data according to requested type.*/
    iec_comm_buffer[3] = type;
    switch(type)
    {
#ifdef TARIFF_SYS
    case TRF_DATA:
      data_size = IEC_62056_21_GET_TRF_DATA(iec_comm_buffer + 4);
      break;
#endif
    case METERING_DATA:
      /*! - Copy metering data.*/
      data_size = IEC_62056_21_GET_METERING_DATA(iec_comm_buffer + 4);
      break;
    case CTRL_DATA:
      /*! - Copy control data.*/
      data_size = IEC_62056_21_GET_CTRL_DATA(iec_comm_buffer + 4);
      break;
    case INST_DATA:
      /*! - Copy instant data.*/
      data_size = IEC_62056_21_GET_INST_DATA(iec_comm_buffer + 4);
      break;
    case TRF_CFG_DATA:
      /*! - Copy tariff configuration.*/
      data_size = IEC_62056_21_GET_TRF_CFG_DATA(iec_comm_buffer + 4);
      break;
    case PYMT_CFG_DATA:
      /*! - Copy payment configuration.*/
      data_size = IEC_62056_21_GET_PYMT_CFG_DATA(iec_comm_buffer + 4);
      break;
    case TAX_CFG_DATA:
      /*! - Copy tax configuration.*/
      data_size = IEC_62056_21_GET_TAX_CFG_DATA(iec_comm_buffer + 4);
      break;     
      
      
    // Added by AMR
    case VACATION_CFG_GET:
      data_size = IEC_62056_21_GET_VACATION_CFG_DATA(iec_comm_buffer + 4);
      break;

    case FRIENDLY_CFG_GET:
      data_size = IEC_62056_21_GET_FRIENDLY_CFG_DATA(iec_comm_buffer + 4);
      break;

    case PYMENT_CFG_GET:
      data_size = IEC_62056_21_GET_PYMENT_CFG_DATA(iec_comm_buffer + 4);
      break;
      
    case TARIFF_CFG_GET:
      data_size = IEC_62056_21_GET_TARIFF_CFG_DATA(iec_comm_buffer + 4);
      break;
      
    case TAX_CFG_GET:
      data_size = IEC_62056_21_GET_TAXES_CFG_DATA(iec_comm_buffer + 4);
      break;
      
    case BP_CFG_GET:
      data_size = IEC_62056_21_GET_BP_CFG_DATA(iec_comm_buffer + 4);
      break;
      
    case CONTROL_CFG_GET:
      data_size = IEC_62056_21_GET_CONTROL_CFG_DATA(iec_comm_buffer + 4);
      break;
      
    case MAXIMUM_DEMAND_CFG_GET:
      data_size = IEC_62056_21_GET_MAXIMUM_DEMAND_CFG_DATA(iec_comm_buffer + 4);
      break;
      
    case LIMITER_CFG_GET:
      data_size = IEC_62056_21_GET_LIMITER_CFG_DATA(iec_comm_buffer + 4);
      break;
      
    case TAMPERS_CFG_GET:
      data_size = IEC_62056_21_GET_TAMPERS_CFG_DATA(iec_comm_buffer + 4);
      break;
      
    case OPERATING_POINT_CFG_GET:
      data_size = IEC_62056_21_GET_OPERATING_POINT_CFG_DATA(iec_comm_buffer + 4);
      break;
      
    case ID_CFG_GET:
      data_size = IEC_62056_21_GET_ID_CFG_DATA(iec_comm_buffer + 4);
      break;
      
    case ACTIONS_ALARMS_CFG_GET:
      data_size = IEC_62056_21_GET_ACTIONS_ALARMS_CFG_DATA(iec_comm_buffer + 4);
      break;
      
    case TIME_CFG_GET:
      data_size = IEC_62056_21_GET_TIME_CFG_DATA(iec_comm_buffer + 4);
      break;
      
    case DATE_CFG_GET:
      data_size = IEC_62056_21_GET_DATE_CFG_DATA(iec_comm_buffer + 4);
      break;
      
    case BATTERY_CFG_GET:
      data_size = IEC_62056_21_GET_BATTERY_CFG_DATA(iec_comm_buffer + 4);
      break;
      
    case MAGNETIC_CFG_GET:
      data_size = IEC_62056_21_GET_MAGNETIC_CFG_DATA(iec_comm_buffer + 4);
      break;
      
    case RFID_UNIQUE_ID_CFG_GET:
      data_size = IEC_62056_21_GET_RFID_UNIQUE_ID_CFG_DATA(iec_comm_buffer + 4);
      break;
      
    case GPRS_CFG_GET:
      data_size = IEC_62056_21_GET_GPRS_CFG_DATA(iec_comm_buffer + 4);
      break;
      
    case OVERLOAD_ALARMS_CFG_GET:
      data_size = IEC_62056_21_GET_OVERLOAD_ALARMS_CFG_DATA(iec_comm_buffer + 4);
      break;
    case NEW_CTRL_DATA_GET:
      data_size = IEC_62056_21_GET_NEW_CTRL_DATA(iec_comm_buffer + 4);
      break;
   case COMM_RETURN_CORRUPTION_GET:
     data_size = IEC_62056_21_GET_RETURN_CORRUPTION(iec_comm_buffer + 4);
     break;
   case COMM_RETURN_EEPROM_PAGE:
     data_size = IEC_62056_21_GET_EEPROM_PAGE(iec_comm_buffer + 4);
     break;
      
      
    }
    data_size += 3;
    buffer_ptr += data_size;
    iec_comm_buffer[1] = (uint8_t)data_size;
    iec_comm_buffer[2] = (uint8_t)(data_size >> 8);
  }
  /*! If the request for records from certain log.*/
  else if((type >= MIN_REC_DATA) && (type <= MAX_REC_DATA))
  {
#ifdef FILE_SYS_LOG
#ifdef MTR_SINGLE_PH
    records_num = SwapEndian16(((data_rqst_pckt_t*)iec_comm_buffer) -> num);
    records_begin =SwapEndian16( ((data_rqst_pckt_t*)iec_comm_buffer) -> from);
#else
    records_num = ((data_rqst_pckt_t*)iec_comm_buffer) -> num;
    records_begin =((data_rqst_pckt_t*)iec_comm_buffer) -> from;
#endif
#endif
    iec_comm_buffer[3] = type;
    /*! - Get records of requested type.*/
    switch(type)
    {
/* BPH_REC case removed: billing history came from the tariff/payment module,
   which is not built for the DRU. */
#ifdef CTRL_EVNT_LOG
    case EVNT_REC:
      if(records_num > EVNT_REC_MAX)
        return FALSE;
      data_size = IEC_62056_21_GET_EVNT_RECS(records_begin, records_num, iec_comm_buffer + 4);
      break;
#endif
/* MNY_REC case removed: money-transaction records came from the tariff/payment
   module, which is not built for the DRU. */
/* PRFL_REC case removed: the load-profile log came from the metering module,
   which is not built for the DRU. */
#ifdef CTRL_CFG_METER_LOG
    case CFG_REC:
      if(records_num > CFG_MTR_REC_MAX)
        return FALSE;
      data_size = IEC_62056_21_GET_CFG_RECS(records_begin, records_num, iec_comm_buffer + 4);
      break;
#endif
    }
    data_size += 3;
    buffer_ptr += data_size;
    iec_comm_buffer[1] = (uint8_t)data_size;
    iec_comm_buffer[2] = (uint8_t)(data_size >> 8);
  }
  /*! Common end.*/
  /*! - Save data packet end in buffer.*/
  memcpy(buffer_ptr, &data_pckt_end, 4);
  buffer_ptr += 4;
  /*! - Calculate packet size.*/
  pckt_size = (uint16_t)(buffer_ptr - iec_comm_buffer + 1);
#ifdef GROUP_METER_FEATURE
  *buffer_ptr = calc_crc(iec_comm_buffer + 1, pckt_size - 2,CRC) & 0x7F;
#else
  *buffer_ptr = calc_crc(iec_comm_buffer + 1, pckt_size - 2,checksum) & 0x7F;
#endif
  /*! - If the power is not going down.*/
    /*! - Send the frame saved in communication buffer.*/
    send_frame(iec_comm_buffer, pckt_size);
    return TRUE; 
}

/*!
 * @brief Send data response packet.
 *
 * @par Description:
 * Send data response packet with acknowledge or reject.
 *
 * @param [in] response response type #data_response_t.
 *
 * @return
 * - None.
 */
void send_data_response_pckt(uint8_t response)
{
  /*!@par Pseudo Code:*/
  /*! - Save the packet in the communication buffer and send frame.*/
  iec_comm_buffer[0] = ACK;
  iec_comm_buffer[1] = response;
  if(pckt_type == DATA_BOOTLOADER_PCKT)
  {
    iec_comm_buffer[2] = current_pckt_ID>>8;
    iec_comm_buffer[3] = current_pckt_ID;
    iec_comm_buffer[4] = CR;
    iec_comm_buffer[5] = LF;
    send_frame(iec_comm_buffer, 6);
  }
  else
  {
    iec_comm_buffer[2] = CR;
    iec_comm_buffer[3] = LF;
    send_frame(iec_comm_buffer, 4);
  }
}

/*!
 * @brief Receive new events.
 *
 * @par Description:
 * When an event happens this function does the proper action.
 *
 * @param [in] type Event type one of #iec_62056_21_event_type_t elements.
 *
 * @return
 * - None.
 */
void iec_62056_21_slave_event(uint8_t type)
{
  /*!@par Pseudo Code:*/
  switch(type)
  {
  case IEC_62056_21_PWR_UP:
    /*! - If event type is power up, reset state machine.*/
    reset_state_machine();
    break;
  case IEC_62056_21_NEW_SEC:
    /*! - If event type is new second, increment seconds counter.*/
    second_counter++;
    rs485_counter++;
    break;
  case IEC_62056_21_NEW_TIMER_TICK:
    /*! - If event type is new timer tick, decremnet the counter for waiting
     * master to change the baudrate.*/
    if(~iec62056_21_wait_baud_rate_counter)
      iec62056_21_wait_baud_rate_counter++;
    break;
  }
}

/*!
 * @brief Send main meter data.
 *
 * @par Description:
 * Change baud rate and send main meter data.
 *
 * @param [in] next_state Next state to go to after sending main meter data.
 *
 * @return
 * - None.
 */
void send_main_data(uint8_t next_state)
{
  second_counter = 0;
  /*! - Change buad rate of communication.*/
  /*! - If the received buad rate value is not equal to sent value, complete
   * with baud rate 300.*/
#ifndef GROUP_METER_FEATURE
#if defined(DLMS_ENABLED) || defined (HDLC_PROTOCOL)
if(rise_iec_flag!=1)
#endif
{
  if(iec_comm_buffer[2] >='0' && iec_comm_buffer[2]<='9')
  {
    IEC_62056_21_UART_INIT(Dlms_NoParity, iec_comm_buffer[2]);
  }
  else
  {
    IEC_62056_21_UART_INIT(Dlms_NoParity, /*300*/'0');
  }
}
#endif
  /*! - If the mode in the ack packet is read data specific, change UART settings.*/
  char_mask = SPECIFIC_MASK;
  state = next_state;
  /*! - Reset counter of waiting master to change the baudrate.*/
  iec62056_21_wait_baud_rate_counter = 0;
  wait_baud_rate_flag = TRUE;
}
#endif

/*!
 * @brief Task of communication protocol.
 *
 * @par Description:
 * Check new packets received and reply according to the state machine in the
 * figure. \image html "protocol_state_machine.jpg"
 *
 * @return
 * - None.
 */
#ifdef IEC_62056_21_SLAVE
void iec_62056_21_slave_task(void)
{
#ifdef CRC_INTEGRITY_ENABLE    
  if((DotmatrixSend)&&(iec_comm_buffer[1]==0x04)&&(iec_comm_buffer[2]==0x00)&&(iec_comm_buffer[5]==0x21)&&(iec_comm_buffer[6]==0x0d))
  {
    DotmatrixSend = 0;
    FinishedDotMatrixFlag = 1;
    memset(iec_comm_buffer,0,sizeof(iec_comm_buffer));
  }
#endif
#ifdef GROUP_METERING
  if(IEC_62056_21_MASTER_SLAVE_MODE == iec62056_21_MASTER_MODE)
    return;
#endif
  /*!@par Pseudo Code:*/
  if(!IEC_62056_21_IS_PWR_DWN())
  {
#ifdef IEC_62056_21_ISR_ENABLE
    iec_62056_21_sub_task();
#endif
    /*! - Check timeout variable.*/
#ifndef GROUP_METERING
    if(second_counter >= IEC_TIMEOUT_SEC)
    {
      reset_state_machine();
    }
#endif
#ifdef RS485_ENABLE
    if(rs485_counter >= RS_485_TIMEOUT)
    {
      reset_state_machine();
      iec62056_21_lcd_icon_flg &= 0xFD;
    }
#endif
    /*! - Check for new packets.*/
    if(!IEC_62056_21_IS_PWR_DWN())
    {
      if((wait_baud_rate_flag) && (iec62056_21_wait_baud_rate_counter > WAIT_BAUD_RATE_PERIOD ))            //WAIT_BAUD_RATE_PERIOD))//WAIT_BAUD_RATE_PERIOD))
      {
        wait_baud_rate_flag = FALSE;
        /*! - Send new data list packet and move to next state.*/
        if(!send_data_pckt(MAIN_METER_DATA))
          reset_state_machine();
        pckt_size = 0;
      }
      
      if((wait_baud_rate_readout_flag) && (iec62056_21_wait_baud_rate_counter > WAIT_BAUD_RATE_PERIOD))
      {
        wait_baud_rate_readout_flag = FALSE;
        /*! - Send new data list packet and move to next state.*/
        send_data_pckt(READOUT_DATA_STND_SEND);                                
        reset_state_machine();
      }      
      
      if(pckt_size)
      {
        /*! - Check validity of received packet and get its type.*/
        if(check_pckt_valid())
        {
          switch(state)
          {
          case IDLE:
            if(pckt_size == 5 && ((iec62056_21_lcd_icon_flg & IEC_OPTICAL) || (iec62056_21_lcd_icon_flg & IEC_OPTICAL_RS) == 0))
            {
              /*! - Set optical flag.*/
              iec62056_21_lcd_icon_flg |= IEC_OPTICAL;
              IEC_62056_21_UART_INIT(Dlms_EvenParity, /*300*/'0'); ////
             } 
            else
            {
              /*! - Set RS485 connect flag.*/
              iec62056_21_lcd_icon_flg |= IEC_RS;
              rs485_counter = 0;
              IEC_62056_21_UART_INIT(Dlms_EvenParity , /*300*/'0'); ////
            }
            /*! - Update LCD.*/
            //IEC_62056_21_UPDATE_LCD(); TODO
            /*! - If we are in IDLE state the received packet must be request.*/
            /*! - Move to WAIT_ACK state.*/
            state = WAIT_ACK;
            /*! - Form Identification packet in the buffer.*/
            iec_comm_buffer[0] = '/';
            iec_comm_buffer[1] = 'S';
            iec_comm_buffer[2] = 'E';
            iec_comm_buffer[3] = 'E';
            if(Boot_loader_flag == RECIEVE_BOOTLOADER_DATA)
             iec_comm_buffer[4] = '5';
            else
            #ifndef DLMS_ENABLED
            iec_comm_buffer[4] = IEC_SPECIFIC_BAUD_RATE;
            int_to_ascii(iec_comm_buffer + 5, IEC_62056_21_GET_CUSTOMER_ID(), 9);
            iec_comm_buffer[14] = CR;
            iec_comm_buffer[15] = LF;
            #else 
            iec_comm_buffer[4] = '6';
            iec_comm_buffer[5] = '\\';
            int_to_ascii(iec_comm_buffer + 6, IEC_62056_21_GET_CUSTOMER_ID(), 11);
            iec_comm_buffer[17] = CR;
            iec_comm_buffer[18] = LF;
            #endif
            if(!IEC_62056_21_IS_PWR_DWN())
              /*! - Send Identification packet.*/
              send_frame(iec_comm_buffer, IDNT_PCKT_LENGTH);
            break;
#ifdef RS485_NetworkDiscovery_Feature
          case SCAN:
            if(!isMeterConnected(iec_comm_buffer)){
              IEC_62056_21_UART_INIT(Dlms_NoParity, /*300*/'0');
              SCAN_MODE_Flag = 1;
            }
            break;
#endif
          case WAIT_ACK:
            /*! - If we are in WAIT ACK state the received packet must be acknowledgment.*/
            if(pckt_type == ACK_PCKT)
            {
#if 1
              if(iec_comm_buffer[3] == READOUT_STND_MODE)
              {
                if(iec_comm_buffer[2] == IEC_SPECIFIC_BAUD_RATE)
                {
#ifndef GROUP_METER_FEATURE
                  IEC_62056_21_UART_INIT(Dlms_EvenParity, IEC_SPECIFIC_BAUD_RATE);
#endif
                }
                /*! - If the mode in the ack packet is readout standard mode, reply by data and then reset.*/
                send_data_pckt(READOUT_DATA_STND_SEND);
                reset_state_machine();
                wait_baud_rate_readout_flag = TRUE;
                iec62056_21_wait_baud_rate_counter = 0;                
              }
              /*! - If mode Read data or Configure, send main meter data.*/
              else
#endif
              if(iec_comm_buffer[3] == READ_DATA_SPCFC_MODE)
                send_main_data(WAIT_DATA_RQST);
              else if(iec_comm_buffer[3] == CFG_MODE)
                send_main_data(WAIT_AUTHNC);
              else if(iec_comm_buffer[3] == BOOTLOADER_MODE)
              {
                IEC_62056_21_SAVE_METER_DATA();
                //ismail//SetBootLoaderKey();       
                CORTEX_NVIC_SystemReset(7);
              }
              else if(iec_comm_buffer[3] == BOOTLOADER_DATA_MODE)
              {
                //Activate boot loader data mode
                if(iec_comm_buffer[2] == '0')
                {
                  iec_comm_buffer[2]='5';
                }
#ifndef GROUP_METER_FEATURE
                IEC_62056_21_UART_INIT(Dlms_NoParity, iec_comm_buffer[2]);
#endif 
                state = WAIT_BOOTLOADER_DATA;
                          
              }
             else if(iec_comm_buffer[3]==WRITE_EEPROM_MODE)
              {
               send_main_data(WAIT_CMD);
              }
             /* TOOLING_MODE branch removed: the self-test / tooling module is not
                built for the DRU. A TOOLING_MODE request now falls through to
                reset_state_machine() below. */
              else
                reset_state_machine();
            }
            break;
          case WAIT_CMD:
            /*! - If the state is WAIT_CMD and the coming packet is command one, handle command.*/
            if(pckt_type == DATA_CMD_PCKT)
            {
              ctrl_sys_var_second_optional_feature.test_interface=TRF_PYMT_INT_OPTICAL;
              if(IEC_62056_21_HANDLE_CMD((uint8_t*)(iec_comm_buffer + 6), pckt_size - 11)==1)
                send_data_response_pckt(ACKNLDG);
              else
                send_data_response_pckt(REJECTED);
              customer_flag = 0;
              /* trf_find_tariff_step_consumption() removed: the tariff/payment
                 module is not built for the DRU. */
            }
            else
              reset_state_machine();
            break;
           
          case WAIT_DATA_RQST:
            /*! - If the state is WAIT_RQST reply by the required data packet.*/
            if(pckt_type == DATA_RQST_PCKT)
            {
              if((iec_comm_buffer[3] >= MIN_RAW_DATA) && (iec_comm_buffer[3] <= MAX_RAW_DATA))
              {
                if(!send_data_pckt(iec_comm_buffer[3]))
                  reset_state_machine();
              }
              else if((iec_comm_buffer[3] >= MIN_REC_DATA) && (iec_comm_buffer[3] <= MAX_REC_DATA))
              {
                if(!send_data_pckt(iec_comm_buffer[3]))
                  reset_state_machine();
              }
              else
                reset_state_machine();
            }
            else
              reset_state_machine();
            break;
          case WAIT_AUTHNC:
            if(pckt_type == DATA_AUTHNC_PCKT)
            {
              /*! - Send data response with ACK.*/
              send_data_response_pckt(ACKNLDG);
              /*! - Move to state WAIT_CMD.*/
              state = WAIT_CMD;
              /*! - Save the operator ID.*/
              last_operator_id = convertToInt16(&iec_comm_buffer[10], BS_BIG_ENDIAN_TYPE);
            }
            else
              reset_state_machine();
            break;
          }
        }
        else
        {
          if(!passing_wrong_pckt_flag)
          {
#ifndef GROUP_METER_FEATURE
          send_data_response_pckt(REJECTED);
#endif
            reset_state_machine();
          }
          passing_wrong_pckt_flag=0;
        }
        pckt_size = 0;
      }
    }
  }
//#endif
}


uint8_t iec62056_21_slave_check_is_idle (void)
{
  
  if (state == IDLE)
    return TRUE;
  return FALSE;
}


void iec62056_21_slave_goto_bootloader(void)
{
  
  pckt_type = ACK_PCKT;
  pckt_size = 6;
  second_counter = 0;
  state = WAIT_ACK;
  //state = WAIT_BOOTLOADER_DATA;
}
#endif