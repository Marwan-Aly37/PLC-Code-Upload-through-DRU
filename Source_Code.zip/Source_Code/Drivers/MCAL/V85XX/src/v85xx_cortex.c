#include "config.h"
#if (MicroController == Micro_V85XX)
/**
  ******************************************************************************
  * @file    v85xx_cortex.c 
  * @author  VT Application Team
  * @version V1.0.0
  * @date    2017-06-22
  * @brief   Cortex module driver.
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "v85xx_cortex.h"
#include "core_cm0.h"
#include "dependencies_layer.h"
#include "v85xx_gpio.h"
/**
  * @brief  1. Clears Pending of a device specific External Interrupt.
  *         2. Sets Priority of a device specific External Interrupt.
  *         3. Enables a device specific External Interrupt. 
  * @param  IRQn: External interrupt number .
  *         This parameter can be an enumerator of IRQn_Type enumeration
  *         (For the complete V85XX Devices IRQ Channels list, please refer to v85xx.h file)
  * @param  Priority: The preemption priority for the IRQn channel.
  *         This parameter can be a value between 0 and 3.
  *         A lower priority value indicates a higher priority
  * @retval None
  */
void CORTEX_SetPriority_ClearPending_EnableIRQ(IRQn_Type IRQn, uint32_t Priority)
{
  /* Check parameters */
  assert_param(IS_CORTEX_NVIC_DEVICE_IRQ(IRQn));
  assert_param(IS_CORTEX_NVIC_PREEMPTION_PRIORITY(Priority));

  /* Clear Pending Interrupt */
  NVIC_ClearPendingIRQ(IRQn);
  /* Set Interrupt Priority */
  NVIC_SetPriority(IRQn, Priority);
  /* Enable Interrupt in NVIC */
  NVIC_EnableIRQ(IRQn);
}

/**
  * @brief  Enables a device specific interrupt in the NVIC interrupt controller.
  * @note   To configure interrupts priority correctly before calling it.
  * @param  IRQn External interrupt number.
  *         This parameter can be an enumerator of IRQn_Type enumeration
  *         (For the complete V85XX Devices IRQ Channels list, please refer to the appropriate CMSIS device file (v85xx.h))
  * @retval None
  */
void CORTEX_NVIC_EnableIRQ(IRQn_Type IRQn)
{
  /* Check parameters */
  assert_param(IS_CORTEX_NVIC_DEVICE_IRQ(IRQn));
  /* Enable interrupt in NVIC */
  NVIC_EnableIRQ(IRQn);
}

/**
  * @brief  Disables a device specific interrupt in the NVIC interrupt controller.
  * @param  IRQn External interrupt number.
  *         This parameter can be an enumerator of IRQn_Type enumeration
  *         (For the complete V85XX Devices IRQ Channels list, please refer to the appropriate CMSIS device file (v85xx.h))
  * @retval None
  */
void CORTEX_NVIC_DisableIRQ(IRQn_Type IRQn)
{
  /* Check parameters */
  assert_param(IS_CORTEX_NVIC_DEVICE_IRQ(IRQn));
  /* Disable interrupt in NVIC */
  NVIC_DisableIRQ(IRQn); 
}

/**
  * @brief  Initiates a system reset request to reset the MCU.
  * @retval None
  */
void CORTEX_NVIC_SystemReset(uint8_t x)
{
  #if 0 // RESET DEBUG
  uint8_t ii;
  /* System Reset */
    for (ii=0;ii<x;ii++)
    {
      GPIOBToF_ResetBits(GPIOF, 1);
      Delay_ms(1000);
      GPIOBToF_SetBits(GPIOF, 1);
      Delay_ms(1000);
    }
#endif

  /*RmvCodCmntA_K*/

  NVIC_SystemReset();

}

/**
  * @brief  Gets the Pending bit of an interrupt.
  * @param  IRQn: External interrupt number.
  *         This parameter can be an enumerator of IRQn_Type enumeration
  *         (For the complete V85XX Devices IRQ Channels list, please refer to the appropriate CMSIS device file (v85xx.h))
  * @retval 0  Interrupt status is not pending.
            1  Interrupt status is pending.
  */
uint32_t CORTEX_NVIC_GetPendingIRQ(IRQn_Type IRQn)
{
  /* Check parameters */
  assert_param(IS_CORTEX_NVIC_DEVICE_IRQ(IRQn));
  /* Get priority for Cortex-M0 system or device specific interrupts */
  return NVIC_GetPendingIRQ(IRQn);  
}

/**
  * @brief  Sets Pending bit of an external interrupt.
  * @param  IRQn External interrupt number
  *         This parameter can be an enumerator of IRQn_Type enumeration
  *         (For the complete V85XX Devices IRQ Channels list, please refer to the appropriate CMSIS device file (v85xx.h))
  * @retval None
  */
void CORTEX_NVIC_SetPendingIRQ(IRQn_Type IRQn)
{
  /* Check parameters */
  assert_param(IS_CORTEX_NVIC_DEVICE_IRQ(IRQn));
  /* Set interrupt pending */
  NVIC_SetPendingIRQ(IRQn);
}

/**
  * @brief  Clears the pending bit of an external interrupt.
  * @param  IRQn External interrupt number.
  *         This parameter can be an enumerator of IRQn_Type enumeration
  *         (For the complete V85XX Devices IRQ Channels list, please refer to the appropriate CMSIS device file (v85xx.h))
  * @retval None
  */
void CORTEX_NVIC_ClearPendingIRQ(IRQn_Type IRQn)
{
  /* Check parameters */
  assert_param(IS_CORTEX_NVIC_DEVICE_IRQ(IRQn));
  /* Clear interrupt pending */
  NVIC_ClearPendingIRQ(IRQn);  
}

/**
  * @brief  Gets the priority of an interrupt.
  * @param  IRQn: External interrupt number.
  *         This parameter can be an enumerator of IRQn_Type enumeration
  *         (For the complete V85XX Devices IRQ Channels list, please refer to the appropriate CMSIS device file (v85xx.h))
  * @retval Interrupt Priority. Value is aligned automatically to the implemented
  *         priority bits of the microcontroller.
  */
uint32_t CORTEX_NVIC_GetPriority(IRQn_Type IRQn)
{
  /* Get priority for Cortex-M0 system or device specific interrupts */
  return NVIC_GetPriority(IRQn);
}

/**
  * @brief  Sets the priority of an interrupt.
  * @param  IRQn: External interrupt number .
  *         This parameter can be an enumerator of IRQn_Type enumeration
  *         (For the complete V85XX Devices IRQ Channels list, please refer to v85xx.h file)
  * @param  Priority: The preemption priority for the IRQn channel.
  *         This parameter can be a value between 0 and 3.
  *         A lower priority value indicates a higher priority  
  * @retval None
  */
void CORTEX_NVIC_SetPriority(IRQn_Type IRQn, uint32_t Priority)
{
  /* Check parameters */
  assert_param(IS_CORTEX_NVIC_PREEMPTION_PRIORITY(Priority));
  /* Get priority for Cortex-M0 system or device specific interrupts */
  NVIC_SetPriority(IRQn, Priority);
}

/**
  * @brief  Initializes the System Timer and its interrupt, and starts the System Tick Timer.
  *         Counter is in free running mode to generate periodic interrupts.
  * @param  TicksNumb: Specifies the ticks Number of ticks between two interrupts.
  * @retval status:  - 0  Function succeeded.
  *                  - 1  Function failed.
  */
uint32_t CORTEX_SystemTick_Config(uint32_t TicksNum)
{
  return SysTick_Config(TicksNum);
}

#endif  /* MicroController */
/******************* (C) COPYRIGHT Vango Technologies, Inc *****END OF FILE****/
