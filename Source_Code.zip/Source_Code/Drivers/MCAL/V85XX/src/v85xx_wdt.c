#include "config.h"
#if (MicroController == Micro_V85XX)

/**
  ******************************************************************************
  * @file    v85xx_wdt.c 
  * @author  VT Application Team
  * @version V1.0.0
  * @date    2017-06-22
  * @brief   WDT library.
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */
#include "v85xx_wdt.h"

#define WDTPASS_KEY 0xAA5555AA
#define WDTCLR_KEY  0x55AAAA55

/**
  * @brief  Enable WDT timer.
  * @param  None
  * @retval None
  */
void WDT_Enable(void)
{
  PMU->WDTPASS = WDTPASS_KEY;
  PMU->WDTEN |= PMU_WDTEN_WDTEN;
  
  PMU->WDTPASS = WDTPASS_KEY;
  PMU->WDTEN |= PMU_WDTEN_WDTEN;
}

/**
  * @brief  Disable WDT timer.
  * @param  None
  * @retval None
  */
void WDT_Disable(void)
{
  PMU->WDTPASS = WDTPASS_KEY;
  PMU->WDTEN &= ~PMU_WDTEN_WDTEN;
  
  PMU->WDTPASS = WDTPASS_KEY;
  PMU->WDTEN &= ~PMU_WDTEN_WDTEN;
}

/**
  * @brief  Clear WDT counter.
  * @param  None
  * @retval None
  */
void WDT_Clear(void)
{
  PMU->WDTCLR = WDTCLR_KEY;
}

/**
  * @brief  Set WDT counting period.
  * @param  counting period:
               WDT_2_SECS
               WDT_1_SECS
               WDT_0_5_SECS
               WDT_0_25_SECS
  * @retval None
  */
void WDT_SetPeriod(uint32_t period)
{
  uint32_t tmp;
  
  assert_param(IS_WDT_PERIOD(period));
    
  tmp = PMU->WDTEN;
  tmp &= ~PMU_WDTEN_WDTSEL;
  tmp |= period;
  PMU->WDTPASS = WDTPASS_KEY;
  PMU->WDTEN = tmp;
}

/**
  * @brief  Get WDT counter value.
  * @param  None
  * @retval current counter value.
  */
uint16_t WDT_GetCounterValue(void)
{
  return (PMU->WDTCLR & PMU_WDTCLR_WDTCNT);
}


#endif /* MicroController */
/******************* (C) COPYRIGHT Vango Technologies, Inc *****END OF FILE****/
